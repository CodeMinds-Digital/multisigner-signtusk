export const PAUSE_COUPON_ID = {
  old: { prod: "V1uIzDQU", test: "3Fs2L1Tq" },
  new: { prod: "V1uIzDQU", test: "3Fs2L1Tq" },
};
