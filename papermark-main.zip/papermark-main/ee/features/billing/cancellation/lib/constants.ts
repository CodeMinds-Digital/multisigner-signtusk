export type CancellationReason =
  | "too_expensive"
  | "unused"
  | "missing_features"
  | "switched_service"
  | "other";
