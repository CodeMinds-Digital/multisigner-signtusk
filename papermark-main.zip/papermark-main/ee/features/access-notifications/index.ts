export { reportDeniedAccessAttempt } from "./lib/report-denied-access-attempt";
