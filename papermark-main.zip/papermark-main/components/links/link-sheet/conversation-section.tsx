import ConversationSection from "@/ee/features/conversations/components/dashboard/link-option-conversation-section";

export default ConversationSection;
