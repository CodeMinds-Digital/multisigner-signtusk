"use client";

import { PermissionsSheet as PermissionsSheetEE } from "@/ee/features/permissions/components/permissions-sheet";

export function PermissionsSheet(props: any) {
  return <PermissionsSheetEE {...props} />;
}
