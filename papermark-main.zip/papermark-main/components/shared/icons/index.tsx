"use client";

import { ComponentType, SVGProps } from "react";

import { LucideIcon } from "lucide-react";

export type Icon = LucideIcon | ComponentType<SVGProps<SVGSVGElement>>;
