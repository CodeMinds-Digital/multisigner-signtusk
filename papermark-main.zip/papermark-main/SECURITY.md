# Security Policy

## Supported Versions

The latest version of Papermark is currently being supported with security updates.

## Reporting a Vulnerability

To report a vulnerability, send an email to security@papermark.com.

We will respond within 48 hours acknowledging your report with details about next steps and potential rewards/compensation for responsible disclosure.
